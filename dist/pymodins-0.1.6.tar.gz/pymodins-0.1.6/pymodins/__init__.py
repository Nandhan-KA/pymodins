
from .installer import installer, run

__version__ = "0.1.6"
